Removed. See 'rvm help get' for updating RVM itself.


Usage:

  rvm build <ruby_string> [options]

ruby_string is of the format $interpreter-$version-$patchlevel

Options:


